# Faithful32 1.12.2 Modded

This Pack does not cover Vanilla textures. Use [Faithful Java 1.12 by xMrVizzy](https://minecraft.curseforge.com/projects/faithful-32x/files/2480942)


We are also on [Curseforge](https://minecraft.curseforge.com/projects/faithful32-modded)

## Discord

You can give feedback and make suggestions by opening an issue
**OR** be a cool boy and join our [Discord Channel](https://discord.gg/yAGW65u)\
Server Code: yAGW65u

## Mod List

See [here](MODLIST.md)

## License

The work in this repository is licensed under the\
[*Creative Commons Attribution-NonCommercial-ShareAlike-4.0 International Public License*](https://creativecommons.org/licenses/by-nc-sa/4.0)\
(Short: [*CC-BY-NC-SA 4.0*](https://creativecommons.org/licenses/by-nc-sa/4.0))\
See [here](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode) for further Information
