These assets were originally created by the Team CoFH and 
are licenced under the the 
Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0),
summarized here: https://creativecommons.org/licenses/by-nc-sa/4.0/

I only removed the stone-background.

Source: https://github.com/CoFH/ThermalFoundation
